// provide alternate entry point so that dm.js and soundex.js can be called the same way
function getSoundex(input, strictRules) {
  return amerSoundex(input, strictRules);
}

function amerSoundex(input, strictRules) {
  var result = "";
  var lastcode = "";
  var first = true;
  for (var i=0; i<input.length; i++) {
    var ch = input.charAt(i).toLowerCase();
    if (ch < 'a' || ch > 'z') {
      continue;
    }
    switch (ch) {
      case 'b':
      case 'f':
      case 'p':
      case 'v':
        if (lastcode != "1") {
          result += "1";
          lastcode = "1";
        }
        break;
      case 'c':
      case 'g':
      case 'j':
      case 'k':
      case 'q':
      case 's':
      case 'x':
      case 'z':
        if (lastcode != "2") {
          result += "2";
          lastcode = "2";
        }
        break;
      case 'd':
      case 't':
        if (lastcode != "3") {
          result += "3";
          lastcode = "3";
        }
        break;
      case 'l':
        if (lastcode != "4") {
          result += "4";
          lastcode = "4";
        }
        break;
      case 'm':
      case 'n':
        if (lastcode != "5") {
          result += "5";
          lastcode = "5";
        }
        break;
      case 'r':
        if (lastcode != "6") {
          result += "6";
          lastcode = "6";
        }
        break;
      case 'a':
      case 'e':
      case 'i':
      case 'o':
      case 'u':
      case 'y':
        lastcode = "";
        break;
      case 'w':
      case 'h':
        if (!strictRules) {
          lastcode = "";
        }
        break;
    }
    if (first) {
      result = input.charAt(i).toUpperCase();
      first = false;
    }
    if (result.length >= 4) {
      break;
    }
  }
  if (result.length == 1) {
    result += "000";
  } else if (result.length == 2) {
    result += "00";
  } else if (result.length == 3) {
    result += "0";
  }
  return result;
}
