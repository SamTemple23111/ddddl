      function trim(stringToTrim) {
      	return stringToTrim.replace(/^\s+|\s+$/g,"");
      }

      function Hide1(id) { // removes space taken up by element
        var object = document.getElementById(id);
        object.style.display = "none";
      }

      function Show1(id) { // makes space for element
        var object = document.getElementById(id);
        object.style.display = "";
      }

      function NewState() {
        document.getElementById("soundex").innerHTML = "";
        var state = document.myform.state[document.myform.state.selectedIndex].value;
        if (state == "MD" || state == "MI" || state == "MN") {
          Hide1("altLicense");
          Show1("day");
          Hide1("year");
          Hide1("gender");
          Hide1("eyeColor");
        } else if (state == "FL" || state == "IL" || state == "WI") {
          Hide1("altLicense");
          Show1("day");
          Show1("year");
          Show1("gender");
          Hide1("eyeColor");
        } else if (state == "NH") {
          Hide1("altLicense");
          Show1("day");
          Show1("year");
          Hide1("gender");
          Hide1("eyeColor");
        } else if (state == "WA") {
          Show1("altLicense");
          Show1("day");
          Show1("year");
          Hide1("gender");
          Hide1("eyeColor");
        } else if (state == "NJ") {
          Hide1("altLicense");
          Hide1("day");
          Show1("year");
          Show1("gender");
          Show1("eyeColor");
        } else {
          alert("invalid state 1");
        }
        CalculateDL();
        CalculateIdentity();
      }

      function Init() {
/*
        document.myform.last.value = "Smith";
        document.myform.first.value = "William";
        document.myform.middle.value = "Henry";
        document.myform.month.selectedIndex = 6;
        document.myform.day.selectedIndex = 4;
        document.myform.year.selectedIndex = 50;
        document.myform.gender.selectedIndex = 0;
*/
        NewState();
      }

      function ChecksumDigit_WA(x) {
        if (x >= "0" && x <= "9") return x
        if (x == "*") return "4";
        if (x == "A") return "1";
        if (x == "B") return "2";
        if (x == "C") return "3";
        if (x == "D") return "4";
        if (x == "E") return "5";
        if (x == "F") return "6";
        if (x == "G") return "7";
        if (x == "H") return "8";
        if (x == "I") return "9";
        if (x == "J") return "1";
        if (x == "K") return "2";
        if (x == "L") return "3";
        if (x == "M") return "4";
        if (x == "N") return "5";
        if (x == "O") return "6";
        if (x == "P") return "7";
        if (x == "Q") return "8";
        if (x == "R") return "9";
        if (x == "S") return "2";
        if (x == "T") return "3";
        if (x == "U") return "4";
        if (x == "V") return "5";
        if (x == "W") return "6";
        if (x == "X") return "7";
        if (x == "Y") return "8";
        if (x == "Z") return "9";
        return "?";
      }

      var valid = true;

      function CalculateDL() {
        valid = true; // true until we learn otherwise
        var lastName = document.myform.last.value.toLowerCase();
        var firstName = document.myform.first.value.toLowerCase();
        var middleName = document.myform.middle.value.toLowerCase();
        var month = document.myform.month[document.myform.month.selectedIndex].value;
        var day = document.myform.day[document.myform.day.selectedIndex].value;
        var state = document.myform.state[document.myform.state.selectedIndex].value;

        var lastCode = amerSoundex(lastName, true);
        if (lastCode == "") {
          lastCode = "0000"; // so that initial display of license doesn't look strange
        }
        var firstCode = "000";
        var middleCode = "000";
        var dobCode = "000";

        // MARYLAND, MICHIGAN, MINNESOTA

        if (state == "MD" || state == "MI" || state == "MN") {

          var fullyCoded = "";
          var firstUnused = "";

          // encode first and middle name

          for (var i=firstMiddleName_MD_MI_MN.length-1; i>=0; i--) { // start from end to get longest match
            var target = firstMiddleName_MD_MI_MN[i][0].toLowerCase();
            if (target.length > firstName.length) {
              continue;
            }
            if (firstName.substr(0, target.length) == target) {
              firstCode = String(firstMiddleName_MD_MI_MN[i][1]);
              fullyCoded = (firstName == target);
              if (!fullyCoded) {
                firstUnused = firstName.charAt(target.length);
              }
              break;
            }
          }
          while (firstCode.length < 3) {
            firstCode = "0" + firstCode;
          }

          if (middleName != "") {
            for (var i=firstMiddleName_MD_MI_MN.length-1; i>=0; i--) { // start from end to get longest match
              var target = firstMiddleName_MD_MI_MN[i][0].toLowerCase();
              if (target.length > middleName.length) {
                continue;
              }
              if (middleName.substr(0, target.length) == target) {
                middleCode = String(firstMiddleName_MD_MI_MN[i][1]);
                break;
              }
            }
          } else { // middle name is blank
            if (fullyCoded) {
              middleCode = "000";
            } else {
              for (var i=0; i<middleName_MD_MI_MN.length; i++) {
                if (middleName_MD_MI_MN[i][0] == firstUnused) {
                  middleCode = String(middleName_MD_MI_MN[i][1]);
                  break;
                }
              }
            }
          }
          while (middleCode.length < 3) {
            middleCode = "0" + middleCode;
          }

          // encode date of birth

          if (month != "00") { // don't encode dob if no month is specified
            var dob = month + day;
            for (var i=0; i<dob_MD_MI_MN.length; i++) {
              if (dob_MD_MI_MN[i][0] == dob) {
                dobCode = String(dob_MD_MI_MN[i][1]);
                break;
              }
            }
          }
          while (dobCode.length < 3) {
            dobCode = "0" + dobCode;
          }

          document.getElementById('license').innerHTML = lastCode + "-" + firstCode + "-" + middleCode + "-" + dobCode;

        // FLORIDA, ILLINOIS, WISCONSIN

        } else if (state == "FL" || state == "IL" || state == "WI") {

          // encode first and middle name

          if (firstName.length == 0) {
            firstCode = 0;
          } else {
            var found = false;
            for (var i=0; i<firstName_FL_IL_WI.length; i++) {
              if (firstName_FL_IL_WI[i][0].toLowerCase() == firstName) {
                firstCode = firstName_FL_IL_WI[i][1];
                 found = true;
                break;
              }
            }
            if (!found) { // exact name was not found, go by the initial
              var firstInitial = firstName.charAt(0).toLowerCase();
              for (var i=0; i<firstInitial_FL_IL_WI.length; i++) {
                if (firstInitial_FL_IL_WI[i][0].toLowerCase() == firstInitial) {
                  firstCode = firstInitial_FL_IL_WI[i][1];
                  break;
                }
              }
            }
          }
          if (middleName.length == 0) {
            middleCode = "";
          } else {
            var middleInitial = middleName.charAt(0).toLowerCase();
            for (var i=0; i<middleInitial_FL_IL_WI.length; i++) {
              if (middleInitial_FL_IL_WI[i][0].toLowerCase() == middleInitial) {
                middleCode = middleInitial_FL_IL_WI[i][1];
                break;
              }
            }
          }
          firstCode = String(firstCode - (-middleCode));
          while (firstCode.length < 3) {
            firstCode = "0" + firstCode;
          }

          // encode year

          var yearCode = document.myform.year[document.myform.year.selectedIndex].value;
          
          // encode dob and gender

          var multiplier = 0;
          var genderCode = 0;
          if (state == "FL" || state == "WI") {
            multiplier = 40;
            if (document.myform.gender[document.myform.gender.selectedIndex].value == "Female") {
              genderCode = 500;
            }
          } else if (state == "IL") {
            multiplier = 31;
            if (document.myform.gender[document.myform.gender.selectedIndex].value == "Female") {
              genderCode = 600;
            }
          }
          var dobCode = String((month-1)*multiplier - (-day) - (-genderCode));
          while (dobCode.length < 3) {
            dobCode = "0" + dobCode;
          }

          // format the license

          if (state == "FL") {
            document.getElementById('license').innerHTML =
              lastCode + "-" + firstCode + "-" + yearCode + "-" + dobCode + "-?";
          } else if (state == "IL") {
            document.getElementById('license').innerHTML =
              lastCode + "-" + firstCode + yearCode.charAt(0) + "-" + yearCode.charAt(1) + dobCode;
          } else if (state == "WI") {
            document.getElementById('license').innerHTML =
              lastCode + "-" + firstCode + yearCode.charAt(0) + "-" + yearCode.charAt(1) + dobCode + "-??";
          }

          // WASHINGTON

        } else if (state == "WA") {

          // encode name

          lastCode = lastName.toUpperCase();
          while (lastCode.length < 5) {
            lastCode += "*";
          }
          lastCode = lastCode.substr(0, 5);

          if (firstName == "") {
            firstCode = "*";
          } else {
            firstCode = firstName.charAt(0).toUpperCase();
          }

          if (middleName == "") {
            middleCode = "*";
          } else {
            middleCode = middleName.charAt(0).toUpperCase();
          }

          // encode dob
          
          var year = document.myform.year[document.myform.year.selectedIndex].value;
          year = year.substr(year.length - 2); // gets the last two digits of the year
          var yearCode = 100 - year;
          yearCode = "0" + yearCode; // so that it is at least two characters long
          yearCode = yearCode.substr(yearCode.length - 2); // so that year 00 doesn't give 100

          var monthCode1 = monthArray1_WA[Number(month)];
          var monthCode2 = monthArray2_WA[Number(month)];

          var dayCode = dayArray_WA[Number(day)];

          var license1 =
            lastCode + firstCode + middleCode + yearCode + monthCode1 + dayCode;
          var license2 =
            lastCode + firstCode + middleCode + yearCode + monthCode2 + dayCode;
          
          // compute checksum

          var checksum1 = 0;
          var checksum2 = 0;
          for (var i=0; i<license1.length; i++) { // both license1 and license2 are the same length
            if (i%2 == 1) {
              checksum1 = checksum1 - ChecksumDigit_WA(license1.charAt(i));              
              checksum2 = checksum2 - ChecksumDigit_WA(license2.charAt(i));              
            } else {
              checksum1 = checksum1 - (-ChecksumDigit_WA(license1.charAt(i)));              
              checksum2 = checksum2 - (-ChecksumDigit_WA(license2.charAt(i)));              
            }
          }
          checksum1 = checksum1 % 10;
          checksum2 = checksum2 % 10;

          license1 = license1.substr(0, 9) + checksum1 + license1.substr(9);
          license2 = license2.substr(0, 9) + checksum2 + license2.substr(9);

          document.getElementById('license').innerHTML = license1;
          document.getElementById('license2').innerHTML = license2;

        // NEW HAMPSHIRE

        } else if (state == "NH") {

          if (lastName == "") {
            lastCode = "00";
          } else if (lastName.length == 1) {
            lastCode = lastName.charAt(0) + "0";
          } else {
            lastCode = lastName.charAt(0) + lastName.charAt(lastName.length - 1);
          }
          if (firstName == "") {
            firstCode = "0";
          } else {
            firstCode = firstName.charAt(0);
          }
          var monthCode = month;
          var yearCode = document.myform.year[document.myform.year.selectedIndex].value;
          yearCode = yearCode.substr(yearCode.length - 2);
          var dayCode = day;

          document.getElementById('license').innerHTML = monthCode + lastCode + firstCode + yearCode + dayCode + "?";

        // NEW JERSEY

        } else if (state == "NJ") {

          if (lastName == "") {
            lastCode = "?????";
          } else {
            lastCode = lastName.charAt(0).toUpperCase() + "????";
          }

          if (firstName.length == 0) {
            firstCode = "???";
          } else {
            var found = false;
            for (var i=0; i<firstName_NJ.length; i++) {
              if (firstName_NJ[i][0].toLowerCase() == firstName) {
                firstCode = firstName_NJ[i][1];
                found = true;
                break;
              }
            }
            if (!found) { // exact name was not found
              firstCode = "???";
            }
          }

          var middleInitial = "";
          if (middleName != "") {
            middleInitial = middleName.charAt(0).toUpperCase();
          }
          var middleInitialCode = "";
          for (var i=0; i<middleInitial_NJ.length; i++) {
            if (middleInitial_NJ[i][0] == middleInitial) {
              middleInitialCode = middleInitial_NJ[i][1];
              break;
            }
          }
          var monthCode = month;
          if (document.myform.gender[document.myform.gender.selectedIndex].value == "Female") {
            monthCode = String(50 + Number(monthCode));
          }
          var yearCode = document.myform.year[document.myform.year.selectedIndex].value;
          var eyeColor = document.myform.eyeColor[document.myform.eyeColor.selectedIndex].text;
          var eyeColorCode = "??";
          for (var i=0; i<eyeColor_NJ.length; i++) {
            if (eyeColor_NJ[i][0] == eyeColor) {
              eyeColorCode = eyeColor_NJ[i][1];
              break;
            }
          }
          document.getElementById('license').innerHTML =
            lastCode + " " + firstCode + middleInitialCode + " " + monthCode + yearCode + eyeColorCode;

        } else {
          alert("invalid state 2");
        }
      }

      function ValidSoundex(soundex) {
        if (soundex.length != 4) {
          return false;
        }
        if (soundex.charAt(0) < "A" || soundex.charAt(0) > "Z") {
          return false;
        }
        var zeroSeen = false;
        for (var i=1; i<soundex.length; i++) {
          if (soundex.charAt(i) < "0" || soundex.charAt(i) > "6") {
            return false;
          }
          if (soundex.charAt(i) == "0") {
            zeroSeen = true;
          } else if (zeroSeen) {
            return false;
          }
        }
        return true;
      }

      function CalculateIdentity() {

        valid = true; // true until we learn otherwise
        var license = trim(document.myform.license.value);
        if (license == "") {
          return;
        }
        var results = "";
        var month = "";
        var day = "";
        var year = "";
        var last = "";
        var first = "";
        var middle = "";
        var gender = "";
        var eyeColor = "";
        var dayCode = "";
        var state = document.myform.state[document.myform.state.selectedIndex].value;

        document.getElementById('identity').innerHTML = "";
        document.getElementById('soundex').innerHTML = "";

        // MARYLAND, MICHIGAN, MINNESOTA, FLORIDA, ILLINOIS, WISCONSIN

        if (state == "MD" || state == "MI" || state == "MN" ||
            state == "FL" || state == "IL" || state == "WI") {

          var firstChar = license.charAt(0);
          if (firstChar < "A" || firstChar > "Z") {
            document.getElementById('identity').innerHTML =
              "<font color='red'>Column 1 must be upper-case letter</font>";
            document.getElementById('soundex').innerHTML = "";
            return;
          }
          if (license.length >= 4) {
            var soundex = license.substr(0, 4);

            if (!ValidSoundex(soundex)) {
              valid = false;
              document.getElementById('identity').innerHTML =
                "<font color='red'>Invalid format in columns 1 to 4</font>";
              document.getElementById('soundex').innerHTML = "";
              return;
            } else {
              document.getElementById("soundex").innerHTML = "";
              var req = protocol + "//stevemorse.org/dl/reversesoundex.php?soundex=" + soundex;
              var bObj = new JSONscriptRequest(req); // create a new request object
              bObj.buildScriptTag(); // build a dynamic script tag
              bObj.addScriptTag(); // add the script to the page -- transfers control to ReverseSoundexCallback
            }
          } else {
            document.getElementById("soundex").innerHTML = "";
          }

          if (license.length >= 5 && license.substr(4,1) != "-") {
            valid = false;
            document.getElementById('identity').innerHTML =
              "<font color='red'>Invalid format: column 5 must be a dash</font>";
            document.getElementById('soundex').innerHTML = "";
            return;
          }

          if (license.length >= 8) {
            var firstCode = license.substr(5,3);

            if (state == "MD" || state == "MI" || state == "MN") {
              if (license.length >= 8) {
                var firstCode = license.substr(5,3);
                for (var i=0; i<firstMiddleName_MD_MI_MN.length; i++) {
                  if (firstMiddleName_MD_MI_MN[i][1] == firstCode) {
                    first = firstMiddleName_MD_MI_MN[i][0] + "...";
                  }
                }
              }
              if (license.length >= 9 && license.substr(8,1) != "-") {
                valid = false;
                document.getElementById('identity').innerHTML =
                  "<font color='red'>Invalid format: column 9 must be a dash</font>";
                document.getElementById('soundex').innerHTML = "";
                return;
              }
              if (license.length >= 12) {
                var middleCode = license.substr(9,3);
                for (var i=0; i<firstMiddleName_MD_MI_MN.length; i++) {
                  if (firstMiddleName_MD_MI_MN[i][1] == middleCode) {
                    middle = firstMiddleName_MD_MI_MN[i][0] + "...";
                  }
                }
              }
              if (license.length >= 13 && license.substr(12,1) != "-") {
                valid = false;
                document.getElementById('identity').innerHTML =
                  "<font color='red'>Invalid format: column 13 must be a dash</font>";
                document.getElementById('soundex').innerHTML = "";
                return;
              }
              if (license.length >= 16) {
                var dob = license.substr(13, 3);
                for (var i=0; i<dob_MD_MI_MN.length; i++) {
                  if (dob_MD_MI_MN[i][1] == dob) {
                    month = monthName[Number(dob_MD_MI_MN[i][0].substr(0, 2))];
                    day = dob_MD_MI_MN[i][0].substr(2, 2);
                  }
                }
              }
              document.getElementById('identity').innerHTML =
                "Name: Last <font color='red'>See below</font> " +
                "First  <font color='red'>" + first.charAt(0).toUpperCase() + first.substr(1) + "</font> " +
                "Middle  <font color='red'>" + middle.charAt(0).toUpperCase() + middle.substr(1) + "</font><br>" +
                "Date of Birth: Month <font color='red'>" + month + "</font> Day <font color='red'>" + day + "</font><br>";

            } else if (state == "FL" || state == "IL" || state == "WI") {
              if (license.length >= 8) {
                var firstCode = license.substr(5,3);
                var middleCode = firstCode%20;
                firstCode -= middleCode
                found = false;
                for (var i=0; i<firstName_FL_IL_WI.length; i++) {
                  if (firstName_FL_IL_WI[i][1] == firstCode) {
                    if (first != "") {
                      first += " or "
                    }
                    first += firstName_FL_IL_WI[i][0];
                    found = true;
                  }
                }
                if (!found) {
                  for (var i=0; i<firstInitial_FL_IL_WI.length; i++) {
                    if (firstInitial_FL_IL_WI[i][1] == firstCode) {
                      if (first != "") {
                        first += " or "
                      }
                      first += firstInitial_FL_IL_WI[i][0];
                    }
                  }
                }
                for (i=0; i<middleInitial_FL_IL_WI.length; i++) {
                  if (middleInitial_FL_IL_WI[i][1] == middleCode) {
                    if (middle != "") {
                      middle += " or "
                    }
                    middle += middleInitial_FL_IL_WI[i][0];
                  }
                }
              }

              var multiplier = 0;
              var genderCode = 0;
              if (state == "FL" || state == "WI") {
                multiplier = 40;
                genderCode = 500;
              } else if (state == "IL") {
                multiplier = 31;
                genderCode = 600;
              }
              var dayCodeStart = 0;
              if (state == "FL") {
                dayCodeStart = 12;
                if (license.length >= 9 && license.substr(8,1) != "-") {
                  valid = false;
                  document.getElementById('identity').innerHTML =
                    "<font color='red'>Invalid format: column 9 must be a dash</font>";
                  document.getElementById('soundex').innerHTML = "";
                  return;
                }
                if (license.length >= 11) {
                  year = license.substr(9, 2);
                }
                if (license.length >= 12 & license.substr(11,1) != "-") {
                  valid = false;
                  document.getElementById('identity').innerHTML =
                    "<font color='red'>Invalid format: column 12 must be a dash</font>";
                  document.getElementById('soundex').innerHTML = "";
                  return;
                }
              } else if (state == "IL" || state == "WI") {
                dayCodeStart = 11;
                if (license.length >= 10 && license.substr(9,1) != "-") {
                  valid = false;
                  document.getElementById('identity').innerHTML =
                    "<font color='red'>Invalid format: column 10 must be a dash</font>";
                  document.getElementById('soundex').innerHTML = "";
                  return;
                }
                if (license.length >= 11) {
                  year = license.substr(8,1) + license.substr(10,1);
                }
              }
              if (license.length >= dayCodeStart+3) {
                dayCode = Number(license.substr(dayCodeStart,3));
                gender = "Male";
                if (dayCode > genderCode) {
                  gender = "Female";
                  dayCode -= genderCode;
                }
                day = dayCode % multiplier;
                dayCode -= day;
                month = monthName[dayCode/multiplier + 1];
              }
              document.getElementById('identity').innerHTML =
                "Name: Last <font color='red'>See below</font> " +
                "First  <font color='red'>" + first.charAt(0).toUpperCase() + first.substr(1) + "</font> " +
                "Middle  <font color='red'>" + middle.charAt(0).toUpperCase() + middle.substr(1) + "</font><br>" +
                "Date of Birth: Month <font color='red'>" + month + "</font> " +
                "Day <font color='red'>" + day + "</font> " +
                "Year <font color='red'>" + year + "</font> " +
                "Gender: <font color='red'>" + gender + "</font><br>";
            }

          }

        // WASHINGTON

        } else if (state == "WA") {

          document.getElementById("soundex").innerHTML = "";
          if (license.length > 0) {
            var len = license.length;
            if (len > 5) {
              len = 5;
            }
            last = license.substr(0, len);
            while (last.charAt(last.length-1) == "*") { // get rid of trailing asterisks
              last = last.substr(0, last.length - 1);
            }
            if (last.length == 5) { // there could be more letters
              last += "...";
            }
          }
          if (license.length >=6) {
            first = license.charAt(5);
          }
          if (license.length >= 7) {
            middle = license.charAt(6);
          }
          if (license.length >= 9) {
            year = 100 - Number(license.substr(7, 2));
            if (year == 100) {
              year = 0
            }
            year = String(year);
            if (year.length < 2) {
              year = "0" + year;
            }
          }
          if (license.length >= 11) {
            var monthCode = license.charAt(10);
            var found = false;
            for (var i=1; i<monthArray1_WA.length; i++) {
              if (monthArray1_WA[i] == monthCode) {
                month = monthName[i];
                found = true;
                break;
              }
            }
            if (!found) { // try the alternate encoding
              for (var i=1; i<monthArray2_WA.length; i++) {
                if (monthArray2_WA[i] == monthCode) {
                  month = monthName[i];
                  found = true;
                  break;
                }
              }
            }
          }
          if (license.length >= 12) {
            dayCode = license.charAt(11);
            for (var i=1; i<dayArray_WA.length; i++) {
              if (dayArray_WA[i] == dayCode) {
                day = i;
              }
            }
          }

          // verify the checksum

          var checksum = 0;
          var license1 = license.substr(0, 9) + license.substr(10); // license without checksum
          for (var i=0; i<license1.length; i++) {
            if (i%2 == 1) {
              checksum = checksum - ChecksumDigit_WA(license1.charAt(i));              
            } else {
              checksum = checksum - (-ChecksumDigit_WA(license1.charAt(i)));              
            }
          }
          checksum = checksum % 10;
          var checksumError = "";
          if (checksum != license.charAt(9)) { // checksum error
            checksumError = "Invalid checksum";
          }

          if (license != "") {
            document.getElementById('identity').innerHTML =
              "Name: Last <font color='red'>" + last + "</font> " +
              "First  <font color='red'>" + first + "</font> " +
              "Middle  <font color='red'>" + middle + "</font><br>" +
              "Date of Birth: Month  <font color='red'>" + month + "</font> " +
              "Day  <font color='red'>" + day + "</font> Year <font color='red'>" + year + "</font><br>" +
              "<font color='red'>" + checksumError + "</font>";
        }

        // NEW HAMPSHIRE

        } else if (state == "NH") {

          document.getElementById("soundex").innerHTML = "";
          if (license.length >= 2) {
            month = monthName[Number(license.substr(0, 2))];
          }
          if (license.length >= 4) {
            last = license.charAt(2).toUpperCase() + "..." + license.charAt(3).toLowerCase();
          }
          if (license.length >= 5) {
            first = license.charAt(4).toUpperCase();
          }
          if (license.length >=7) {
            year = license.substr(5, 2);
          }
          if (license.length >= 9) {
            day = license.substr(7, 2);
          }
          if (license != "") {
            document.getElementById('identity').innerHTML =
              "Name: Last <font color='red'>" + last + "</font> " +
              "First  <font color='red'>" + first + "</font><br>" +
              "Date of Birth: Month  <font color='red'>" + month + "</font> " +
              "Day  <font color='red'>" + day + "</font> Year <font color='red'>" + year + "</font>";
          }

        // NEW JERSEY

        } else if (state == "NJ") {

          if (license.length >= 1) {
            last = license.charAt(0) + "...";
          }
          if (license.length >= 6) {
            if (license.charAt(5) != " ") {
              valid = false;
              document.getElementById('identity').innerHTML =
                "<font color='red'>Invalid format: column 6 must be a space</font>";
              return;
            }
          }

          if (license.length >= 9) {

            var firstCode = license.substr(6,3);
            found = false;
            first = "";
            for (var i=0; i<firstName_NJ.length; i++) {
              if (firstName_NJ[i][1] == firstCode) {
                if (first != "") {
                  first += " or "
                }
                first += firstName_NJ[i][0];
                found = true;
              }
            }
          }

          if (license.length >= 11) {
            var middleCode = license.substr(9,2);
            var found = false;
            for (i=0; i<middleInitial_NJ.length; i++) {
              if (middleInitial_NJ[i][1] == middleCode) {
                middle = middleInitial_NJ[i][0];
                found = true;
                break;
              }
            }
            if (!found) {
              valid = false;
              document.getElementById('identity').innerHTML =
                "<font color='red'>Invalid format: columns 10 and 11 must be 00 or a number between 61 and 89</font>";
              return;
            }
          }
          if (license.length >= 12) {
            if (license.charAt(11) != " ") {
              valid = false;
              document.getElementById('identity').innerHTML =
                "<font color='red'>Invalid format: column 12 must be a space</font>";
              return;
            }
          }
          if (license.length >= 14) {
            var monthCode = Number(license.substr(12,2));
            gender = "Male";
            if (monthCode > 50) {
              gender = "Female";
              monthCode -= 50;
            }
            if (monthCode < 1 || monthCode > 12) {
              valid = false;
              document.getElementById('identity').innerHTML =
                "<font color='red'>Invalid format: columns 13 and 14 must be a number betwee 1 and 12 or between 51 and 62</font>";
              return;
            }
            month = monthName[monthCode];
          }
          if (license.length >= 16) {
            year = license.substr(14, 2);
          }
          if (license.length >= 17) {
            var found = false;
            var eyeColorCode = license.charAt(16);
            for (i=0; i<eyeColor_NJ.length; i++) {
              if (eyeColor_NJ[i][1] == eyeColorCode) {
                eyeColor = eyeColor_NJ[i][0];
                found = true;
                break;
              }
            }
            if (!found) {
              valid = false;
              document.getElementById('identity').innerHTML =
                "<font color='red'>Invalid format: columns 18 must be a number</font>";
              return;
            }
          }
          document.getElementById('identity').innerHTML =
            "Name: Last <font color='red'>" + last + "</font> " +
            "First  <font color='red'>" + first + "</font> " +
            "Middle  <font color='red'>" + middle + "</font><br>" +
            "Date of Birth: Month  <font color='red'>" + month + "</font> " +
            "Year <font color='red'>" + year + "</font> " +
            "Gender: <font color='red'>" + gender + "</font> " +
            "Eye Color: <font color='red'>" + eyeColor + "</font><br>";

        } else {
          valid = false;
          document.getElementById("soundex").innerHTML = "";
          alert("invalid state 3");
        }
      }

      function ReverseSoundexCallback(names) {
        if (valid) {
          if (names != "") {
            document.getElementById("soundex").innerHTML =
              "Last name might sound like: <font color='red'>" + names + "</font>";
          } else {
            document.getElementById("soundex").innerHTML =
              "No possible last names found: <font color='red'>" + names + "</font>";
          }
        }
      }
