var protocol = window.location.protocol;
